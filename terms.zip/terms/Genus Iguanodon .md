**Fossil Spotlight: Genus Iguanodon**

**General Details:**
- **Name:** Iguanodon
- **Scientific Classification:** Genus Iguanodon, Family Iguanodontidae
